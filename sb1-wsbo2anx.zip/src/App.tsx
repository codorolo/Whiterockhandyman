import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import ServicesPage from './pages/ServicesPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import BathroomRenovationsPage from './pages/BathroomRenovationsPage';
import KitchenRenovationsPage from './pages/KitchenRenovationsPage';
import CommercialServicesPage from './pages/CommercialServicesPage';
import RatesPage from './pages/RatesPage';
import GalleryPage from './pages/GalleryPage';
import HandymanServicesPage from './pages/HandymanServicesPage';
import EstimatePage from './pages/EstimatePage';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/services/bathroom-renovations" element={<BathroomRenovationsPage />} />
            <Route path="/services/kitchen-renovations" element={<KitchenRenovationsPage />} />
            <Route path="/services/handyman" element={<HandymanServicesPage />} />
            <Route path="/services/commercial" element={<CommercialServicesPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/rates" element={<RatesPage />} />
            <Route path="/gallery" element={<GalleryPage />} />
            <Route path="/estimate" element={<EstimatePage />} />
          </Routes>
        </main>
      </div>
      <Footer />
    </Router>
  );
}

export default App;