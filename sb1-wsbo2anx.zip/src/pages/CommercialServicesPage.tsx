import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, ArrowRight, Clock, Shield, Star, PenTool as Tool } from 'lucide-react';

const CommercialServicesPage = () => {
  return (
    <div>
      {/* Hero Section */}
      <section 
        className="bg-cover bg-center py-20 relative" 
        style={{ 
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url(https://images.unsplash.com/photo-1497366811353-6870744d04b2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80)'
        }}
      >
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Commercial Services
            </h1>
            <p className="text-xl text-white mb-8">
              Professional renovation and maintenance solutions for businesses.
            </p>
            <Link to="/estimate" className="bg-primary hover:bg-red-700 text-white font-medium py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
              Request a Commercial Quote
            </Link>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-center">
              <div className="md:col-span-5">
                <img 
                  src="https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Commercial Renovation" 
                  className="rounded-lg shadow-md w-full h-auto"
                />
              </div>
              <div className="md:col-span-7">
                <h2 className="text-3xl font-bold mb-6">Commercial Renovation & Maintenance</h2>
                <p className="text-gray-700 mb-4">
                  White Rock Handyman & Renovations provides professional commercial services for businesses across White Rock, Surrey, Langley, and surrounding areas. We understand that your business environment needs to be functional, attractive, and maintained with minimal disruption.
                </p>
                <p className="text-gray-700 mb-4">
                  Our team of skilled professionals delivers quality workmanship, reliable service, and timely completion for projects of any size—from small repairs to complete commercial renovations.
                </p>
                <p className="text-gray-700">
                  We work with various commercial clients, including retail stores, offices, restaurants, clinics, and small businesses, providing tailored solutions that align with your business goals and budget.
                </p>
                
                <div className="mt-6 flex flex-wrap items-center">
                  <div className="flex items-center mr-6 mb-2">
                    <Shield size={20} className="text-primary mr-2" />
                    <span className="font-medium">Licensed & Insured</span>
                  </div>
                  <div className="flex items-center mr-6 mb-2">
                    <Clock size={20} className="text-primary mr-2" />
                    <span className="font-medium">38+ Years Experience</span>
                  </div>
                  <div className="flex items-center mb-2">
                    <Star size={20} className="text-primary mr-2" />
                    <span className="font-medium">Quality Workmanship</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Commercial Services */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Commercial Services</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Tool size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Office Renovations</h3>
                    <p className="text-gray-700">
                      Transform your workplace with professional office renovations that improve functionality and aesthetics.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Office space planning & layout</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Interior walls & partitions</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Reception area renovations</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Meeting room upgrades</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Workstation installation</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Tool size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Retail Space Improvements</h3>
                    <p className="text-gray-700">
                      Enhance your retail environment to attract customers and optimize your selling space.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Storefront renovations</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Display installations</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Custom shelving & cabinetry</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Flooring upgrades</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Lighting improvements</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Tool size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Restaurant & Cafe Renovations</h3>
                    <p className="text-gray-700">
                      Create an inviting dining atmosphere that enhances customer experience and operational efficiency.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Dining area renovations</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Bar area construction</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Countertop & service area upgrades</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Custom fixtures & seating</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Kitchen improvements</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Tool size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Commercial Maintenance</h3>
                    <p className="text-gray-700">
                      Keep your business premises in optimal condition with our regular maintenance services.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Preventative maintenance programs</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Electrical & lighting maintenance</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Plumbing repairs</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Door & hardware repairs</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>General repairs & maintenance</span>
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md mt-8">
              <h3 className="text-xl font-bold mb-4 text-primary">Additional Commercial Services</h3>
              <p className="text-gray-700 mb-6">
                Our team also provides these specialized commercial services:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start">
                  <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Commercial bathroom renovations</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Accessibility upgrades & modifications</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Commercial painting services</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Flooring installation & replacement</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Tenant improvements</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Commercial carpentry services</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Signage installation</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Emergency repair services</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Approach */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Commercial Approach</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="bg-primary w-12 h-12 rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">1</div>
                <h3 className="text-xl font-bold mb-3">Minimal Disruption</h3>
                <p className="text-gray-700">
                  We understand that downtime costs money. Our team works efficiently to minimize disruption to your business operations, with options for after-hours and weekend work.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="bg-primary w-12 h-12 rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">2</div>
                <h3 className="text-xl font-bold mb-3">Professional Quality</h3>
                <p className="text-gray-700">
                  Your business deserves the best. We deliver professional-grade materials and craftsmanship that stand up to commercial use and create the right impression for your clients.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="bg-primary w-12 h-12 rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">3</div>
                <h3 className="text-xl font-bold mb-3">Detailed Planning</h3>
                <p className="text-gray-700">
                  Our thorough planning process ensures your project stays on schedule and within budget. We provide clear timelines and regular updates throughout the project.
                </p>
              </div>
            </div>
            
            <div className="mt-10 bg-white p-8 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-4 text-center">Safety & Compliance</h3>
              <p className="text-gray-700 mb-6 text-center">
                All our commercial services are completed with strict adherence to safety protocols and building codes. We maintain proper licensing, insurance, and WorkSafeBC compliance for your protection.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                <div className="flex flex-col items-center">
                  <Shield size={48} className="text-primary mb-3" />
                  <h4 className="font-bold text-center mb-2">Fully Licensed & Insured</h4>
                  <p className="text-sm text-gray-700 text-center">
                    Comprehensive insurance coverage for commercial projects
                  </p>
                </div>
                
                <div className="flex flex-col items-center">
                  <Shield size={48} className="text-primary mb-3" />
                  <h4 className="font-bold text-center mb-2">Code Compliant</h4>
                  <p className="text-sm text-gray-700 text-center">
                    All work meets or exceeds local building code requirements
                  </p>
                </div>
                
                <div className="flex flex-col items-center">
                  <Shield size={48} className="text-primary mb-3" />
                  <h4 className="font-bold text-center mb-2">WorkSafeBC Certified</h4>
                  <p className="text-sm text-gray-700 text-center">
                    Strict adherence to workplace safety standards
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Commercial Portfolio */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Our Commercial Portfolio</h2>
            <p className="text-lg text-gray-700 mb-12">
              Browse examples of our commercial renovation and maintenance projects.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="overflow-hidden rounded-lg shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1497366811353-6870744d04b2?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                  alt="Office Renovation" 
                  className="w-full h-64 object-cover transition-transform duration-300 hover:scale-105"
                />
                <div className="p-4 bg-white">
                  <h3 className="font-bold">Office Renovation</h3>
                  <p className="text-sm text-gray-700">Surrey, BC</p>
                </div>
              </div>
              
              <div className="overflow-hidden rounded-lg shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                  alt="Retail Store Upgrade" 
                  className="w-full h-64 object-cover transition-transform duration-300 hover:scale-105"
                />
                <div className="p-4 bg-white">
                  <h3 className="font-bold">Retail Store Upgrade</h3>
                  <p className="text-sm text-gray-700">White Rock, BC</p>
                </div>
              </div>
              
              <div className="overflow-hidden rounded-lg shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1559305616-3f99cd43e353?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                  alt="Restaurant Renovation" 
                  className="w-full h-64 object-cover transition-transform duration-300 hover:scale-105"
                />
                <div className="p-4 bg-white">
                  <h3 className="font-bold">Restaurant Renovation</h3>
                  <p className="text-sm text-gray-700">Langley, BC</p>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <Link to="/gallery" className="text-primary font-medium flex items-center justify-center hover:underline">
                View our full commercial project gallery <ArrowRight size={18} className="ml-1" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">What Our Commercial Clients Say</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-primary">
                <p className="text-gray-700 mb-4 italic">
                  "White Rock Handyman renovated our dental clinic with minimal disruption to our practice. The work was completed on time and on budget, with excellent attention to detail. We're extremely pleased with the results."
                </p>
                <p className="font-bold">- Dr. James Wilson, Surrey Dental Care</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-primary">
                <p className="text-gray-700 mb-4 italic">
                  "We've been using White Rock Handyman for all our retail maintenance needs for over 5 years. Their response time is excellent, and their work is always professional. They understand the importance of maintaining our store's appearance."
                </p>
                <p className="font-bold">- Linda Chen, Boutique Manager</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Common Commercial Questions</h2>
            
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">Can you work after hours to minimize business disruption?</h3>
                <p className="text-gray-700">
                  Yes, we regularly schedule work during evenings, weekends, and off-hours to minimize disruption to your business operations. We understand that downtime costs money and will work with you to create a schedule that meets your needs.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">Do you provide maintenance contracts for commercial properties?</h3>
                <p className="text-gray-700">
                  Yes, we offer customized maintenance contracts to keep your commercial property in optimal condition. These can include scheduled maintenance, emergency services, and regular inspections based on your specific requirements.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">Are you licensed and insured for commercial work?</h3>
                <p className="text-gray-700">
                  Absolutely. We are fully licensed, insured, and bonded for commercial projects. We maintain comprehensive liability insurance and WorkSafeBC coverage to ensure protection for both our team and your business throughout the project.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">How do you handle project timelines for commercial renovations?</h3>
                <p className="text-gray-700">
                  We provide detailed project timelines at the outset and keep you updated on progress throughout the renovation. Our experienced team plans efficiently to meet deadlines and minimize any impact on your business operations.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Ready to transform your commercial space?</h2>
            <p className="text-xl text-white mb-8">
              Contact us today to discuss your commercial renovation or maintenance needs and receive a detailed proposal.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/estimate" className="bg-white hover:bg-gray-100 text-primary font-bold py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Request a Commercial Quote
              </Link>
              <Link to="/contact" className="bg-transparent border-2 border-white text-white hover:bg-white/10 font-bold py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Contact Our Commercial Team
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CommercialServicesPage;