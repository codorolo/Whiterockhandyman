import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, ArrowRight, PenTool as Tool } from 'lucide-react';

const HandymanServicesPage = () => {
  const smallJobs = [
    'Sink & Faucet Installations',
    'Ceiling Fan & Bathroom Fan Installations',
    'Door Handle & Lock Replacements',
    'TV Mounting & Home Theatre Installation',
    'Closet Door Repairs & Installations',
    'Toilet Installations & Seat Replacements',
    'Picture & Mirror Hanging',
    'Accent Wall Painting',
    'Furniture Assembly',
    'Custom-built Pieces',
    'Shelving Installations',
    'Kitchen Appliance Installations',
    'Deck Repairs',
    'Drywall Repairs',
    'Tile Installation & Repair',
    'Light Fixture Installations',
    'Light Switch Replacements',
    'Fixing Leaks & Cracks'
  ];

  return (
    <div>
      {/* Hero Section */}
      <section 
        className="bg-cover bg-center py-20 relative" 
        style={{ 
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url(https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80)'
        }}
      >
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Handyman Services
            </h1>
            <p className="text-xl text-white mb-8">
              Professional solutions for all your home repair and improvement needs.
            </p>
            <Link to="/estimate" className="bg-primary hover:bg-red-700 text-white font-medium py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
              Get a Free Estimate
            </Link>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-center">
              <div className="md:col-span-5">
                <img 
                  src="https://images.unsplash.com/photo-1621905251918-48416bd8575a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Handyman Services" 
                  className="rounded-lg shadow-md w-full h-auto"
                />
              </div>
              <div className="md:col-span-7">
                <h2 className="text-3xl font-bold mb-6">Professional Handyman Services</h2>
                <p className="text-gray-700 mb-4">
                  At White Rock Handyman & Renovations, we tackle those nagging home repair and improvement tasks that you never seem to find time for. Our professional handyman services cover everything from small repairs to more complex projects.
                </p>
                <p className="text-gray-700 mb-4">
                  With over 38 years of experience, our licensed and insured team has the expertise to handle virtually any home maintenance or improvement task with precision and care.
                </p>
                <p className="text-gray-700">
                  Whether you have a single repair or a whole list of projects, we deliver quality workmanship and reliable service at competitive rates—with no call-out fees.
                </p>
                
                <div className="mt-6 grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="flex items-center">
                    <CheckCircle size={18} className="text-primary mr-2 flex-shrink-0" />
                    <span className="text-sm">Licensed & Insured</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle size={18} className="text-primary mr-2 flex-shrink-0" />
                    <span className="text-sm">38+ Years Experience</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle size={18} className="text-primary mr-2 flex-shrink-0" />
                    <span className="text-sm">No Call-Out Fees</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle size={18} className="text-primary mr-2 flex-shrink-0" />
                    <span className="text-sm">Free Estimates</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle size={18} className="text-primary mr-2 flex-shrink-0" />
                    <span className="text-sm">Quality Workmanship</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle size={18} className="text-primary mr-2 flex-shrink-0" />
                    <span className="text-sm">Satisfaction Guaranteed</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Handyman Services */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Handyman Services</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Tool size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Painting</h3>
                    <p className="text-gray-700">
                      With over 38 years of experience, painting is not a problem. We only use top quality paint that is washable and can stand the test of time.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Interior painting</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Accent walls</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Ceiling painting</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Exterior painting</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Tool size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Flooring</h3>
                    <p className="text-gray-700">
                      Vinyl, Laminate, or Hardwood... We'll get the job done right the first time with expert installation.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Hardwood flooring</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Laminate flooring</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Vinyl flooring</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Tile installation</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Tool size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Carpentry</h3>
                    <p className="text-gray-700">
                      Need a piece custom built? No problem! From banquettes to fireplace mantles, we do it all with precision.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Custom built-ins</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Shelving & storage solutions</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Trim & molding</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Door repairs & installations</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Tool size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Electrical</h3>
                    <p className="text-gray-700">
                      Home theatre installations, lighting fixtures, dimmers, and small electrical jobs handled safely.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Light fixture installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Ceiling fan installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Switch & outlet replacement</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>TV mounting & home theatre setup</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Tool size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Plumbing</h3>
                    <p className="text-gray-700">
                      From fixing leaky faucets to installing new fixtures, we handle common plumbing tasks with expertise.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Faucet installation & repair</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Sink installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Toilet installation & repair</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Drain unclogging</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Tool size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Drywall & Patching</h3>
                    <p className="text-gray-700">
                      Repair holes, cracks, and damage to walls and ceilings with seamless results that look like new.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Drywall repair & patching</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Hole repair</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Texture matching</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Water damage repair</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* No Job Too Small Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">No Job Too Small</h2>
              <p className="text-lg text-gray-700">
                Whether you've got one small job or a whole to-do list, White Rock Handyman & Renovations will make sure that all of your jobs are done right the first time!
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {smallJobs.map((job, index) => (
                <div key={index} className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>{job}</span>
                </div>
              ))}
            </div>
            
            <div className="bg-gray-light p-6 mt-10 rounded-lg">
              <div className="flex flex-col md:flex-row items-center">
                <div className="text-primary mb-4 md:mb-0 md:mr-6">
                  <svg className="w-16 h-16" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Don't see what you need?</h3>
                  <p className="text-gray-700 mb-4">
                    This is just a sample of the many handyman services we offer. If you don't see your specific need listed, just ask! We're equipped to handle a wide range of home repair and improvement tasks.
                  </p>
                  <Link to="/contact" className="text-primary font-medium flex items-center hover:underline">
                    Contact us about your specific needs <ArrowRight size={18} className="ml-1" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">How It Works</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="bg-primary w-12 h-12 rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">1</div>
                <h3 className="text-xl font-bold mb-3">Contact Us</h3>
                <p className="text-gray-700">
                  Reach out by phone, email, or our online form. Describe your project or repair needs, and we'll schedule a convenient time for an estimate.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="bg-primary w-12 h-12 rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">2</div>
                <h3 className="text-xl font-bold mb-3">Get a Free Estimate</h3>
                <p className="text-gray-700">
                  We'll assess your project and provide a clear, detailed estimate with transparent pricing. No hidden fees or surprise costs.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="bg-primary w-12 h-12 rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">3</div>
                <h3 className="text-xl font-bold mb-3">Job Completion</h3>
                <p className="text-gray-700">
                  Our skilled handymen will arrive on schedule, complete the work efficiently and professionally, and clean up thoroughly when finished.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">What Our Clients Say</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-primary">
                <p className="text-gray-700 mb-4 italic">
                  "I had a long list of small repairs that needed attention around my home. White Rock Handyman completed everything in a single day, with excellent workmanship and attention to detail. Highly recommended!"
                </p>
                <p className="font-bold">- Thomas R., White Rock</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-primary">
                <p className="text-gray-700 mb-4 italic">
                  "The team installed new light fixtures throughout my home and mounted my TV above the fireplace. They were professional, clean, and did an outstanding job. I'll definitely call them again for future projects."
                </p>
                <p className="font-bold">- Amanda S., Surrey</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Pricing Section */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Transparent Pricing</h2>
            <p className="text-lg text-gray-700 mb-8">
              We believe in fair, transparent pricing with no hidden fees. Our handyman services are available on an hourly rate or project basis.
            </p>
            
            <div className="flex justify-center">
              <Link to="/rates" className="bg-primary hover:bg-red-700 text-white font-medium py-3 px-8 rounded-md transition-colors inline-flex items-center">
                View Our Rates <ArrowRight size={18} className="ml-2" />
              </Link>
            </div>
            
            <div className="mt-10 bg-white p-6 rounded-lg shadow-md max-w-md mx-auto">
              <h3 className="text-xl font-bold mb-4">Our Service Guarantee</h3>
              <p className="text-gray-700">
                We stand behind our work. If you're not completely satisfied with our handyman services, we'll make it right—guaranteed.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Ready to get started?</h2>
            <p className="text-xl text-white mb-8">
              Contact us today for a free consultation and quote on your home repair or improvement project.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/estimate" className="bg-white hover:bg-gray-100 text-primary font-medium py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Get a Free Estimate
              </Link>
              <a href="tel:+1234567890" className="bg-transparent border-2 border-white text-white hover:bg-white/10 font-medium py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Call Us: (123) 456-7890
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HandymanServicesPage;