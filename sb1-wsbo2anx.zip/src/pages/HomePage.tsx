import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, Phone, Star, ArrowRight, Award, PenTool as Tool, Shield, Clock, Zap, Paintbrush, Hammer, Wrench } from 'lucide-react';
import GoogleReviews from '../components/GoogleReviews';

const HomePage = () => {
  return (
    <div>
      {/* Hero Section */}
      <section 
        className="bg-cover bg-top py-24 relative" 
        style={{ 
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url(https://imgur.com/Bg5ZvqE.png)'
        }}
      >
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              Quality Handyman & Renovation Services
            </h1>
            <p className="text-xl text-white mb-8">
              Serving White Rock, Surrey, Langley and surrounding areas for over 37 years with professional, reliable home improvement services.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/estimate" className="bg-primary hover:bg-red-700 text-white font-medium py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Get a Free Estimate
              </Link>
              <Link to="/services" className="bg-white hover:bg-gray-100 text-secondary font-medium py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Our Services
              </Link>
            </div>
            
            <div className="flex flex-wrap items-center mt-8">
              <div className="flex items-center mr-6 mb-2">
                <Award size={20} className="text-primary mr-2" />
                <span className="text-white">Licensed & Insured</span>
              </div>
              <div className="flex items-center mr-6 mb-2">
                <Star size={20} className="text-yellow-400 mr-2" />
                <span className="text-white">4.9 Stars (85+ Reviews)</span>
              </div>
              <div className="flex items-center mb-2">
                <CheckCircle size={20} className="text-primary mr-2" />
                <span className="text-white">No Call-Out Fees</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <CheckCircle size={32} className="text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Quality Workmanship</h3>
              <p className="text-gray-700">
                Our experienced team ensures that every job is completed to the highest standards, with attention to detail and quality craftsmanship.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <Clock size={32} className="text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">37+ Years Experience</h3>
              <p className="text-gray-700">
                With over 37 years in the industry, we have the expertise and knowledge to handle any home improvement project with confidence.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <Shield size={32} className="text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Licensed & Insured</h3>
              <p className="text-gray-700">
                We're fully licensed, insured, and bonded for your protection and peace of mind, with all work completed to code requirements.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Services Overview */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Our Services</h2>
            <p className="text-lg text-gray-700 max-w-3xl mx-auto">
              From complete renovations to small repairs, we provide comprehensive home improvement services tailored to your needs and budget.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
              <img 
                src="https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Bathroom Renovations" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Bathroom Renovations</h3>
                <p className="text-gray-700 mb-4">
                  Complete bathroom transformations including tiling, fixtures, vanities, showers, and more.
                </p>
                <Link to="/services/bathroom-renovations" className="text-primary font-medium flex items-center hover:underline">
                  Learn more <ArrowRight size={18} className="ml-1" />
                </Link>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
              <img 
                src="https://images.unsplash.com/photo-1556912167-f556f1f39fdf?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Kitchen Renovations" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Kitchen Renovations</h3>
                <p className="text-gray-700 mb-4">
                  Modern kitchen updates including cabinets, countertops, backsplashes, and appliance installation.
                </p>
                <Link to="/services/kitchen-renovations" className="text-primary font-medium flex items-center hover:underline">
                  Learn more <ArrowRight size={18} className="ml-1" />
                </Link>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
              <img 
                src="https://imgur.com/4vN1k6t.png" 
                alt="Handyman Services" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Handyman Services</h3>
                <p className="text-gray-700 mb-4">
                  From small repairs to maintenance projects, our skilled handymen can tackle your entire to-do list.
                </p>
                <Link to="/services/handyman" className="text-primary font-medium flex items-center hover:underline">
                  Learn more <ArrowRight size={18} className="ml-1" />
                </Link>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
              <img 
                src="https://images.unsplash.com/photo-1497366811353-6870744d04b2?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Commercial Services" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Commercial Services</h3>
                <p className="text-gray-700 mb-4">
                  Professional renovation and maintenance services for offices, retail spaces and commercial properties.
                </p>
                <Link to="/services/commercial" className="text-primary font-medium flex items-center hover:underline">
                  Learn more <ArrowRight size={18} className="ml-1" />
                </Link>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Link to="/services" className="bg-primary hover:bg-red-700 text-white font-medium py-3 px-8 rounded-md transition-colors inline-flex items-center">
              View All Services <ArrowRight size={18} className="ml-2" />
            </Link>
          </div>
        </div>
      </section>

      {/* Secondary Services */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center">Additional Services</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Paintbrush size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Painting</h3>
                    <p className="text-gray-700">
                      With over 37 years of experience, painting is not a problem. We only use top quality paint that is washable and can stand the test of time.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Interior and exterior painting</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Accent walls and decorative painting</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Cabinet painting and refinishing</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Hammer size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Flooring</h3>
                    <p className="text-gray-700">
                      Vinyl, Laminate, or Hardwood... We'll get the job done right the first time with expert installation.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Hardwood flooring</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Laminate flooring</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Vinyl flooring</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Wrench size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Carpentry</h3>
                    <p className="text-gray-700">
                      Need a piece custom built? No problem! From banquettes to fireplace mantles, we do it all with precision.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Custom built-ins</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Shelving & storage solutions</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Trim & molding</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-start mb-6">
                  <div className="bg-primary/10 rounded-full p-3 mr-4">
                    <Zap size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Electrical</h3>
                    <p className="text-gray-700">
                      Home theatre installations, lighting fixtures, dimmers, and small electrical jobs handled safely.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Light fixture installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Ceiling fan installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>TV mounting & home theatre setup</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose White Rock Handyman</h2>
            <p className="text-lg text-gray-700 max-w-3xl mx-auto">
              We pride ourselves on delivering exceptional service and quality craftsmanship on every project.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md border-t-4 border-primary">
              <h3 className="text-xl font-bold mb-3">Licensed & Insured</h3>
              <p className="text-gray-700">
                We're fully licensed, insured, and bonded, so you can have complete peace of mind when we work on your property. All our work is completed to code requirements.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md border-t-4 border-primary">
              <h3 className="text-xl font-bold mb-3">Transparent Pricing</h3>
              <p className="text-gray-700">
                No hidden fees or surprises. We provide detailed quotes before starting work, and there are no call-out fees for estimates. You'll know exactly what you're paying for.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md border-t-4 border-primary">
              <h3 className="text-xl font-bold mb-3">Satisfaction Guaranteed</h3>
              <p className="text-gray-700">
                Your satisfaction is our top priority. We stand behind our work and won't consider a job complete until you're 100% happy with the results.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md border-t-4 border-primary">
              <h3 className="text-xl font-bold mb-3">Experienced Team</h3>
              <p className="text-gray-700">
                With 37+ years of experience, our skilled craftsmen have the expertise to handle projects of any size or complexity with attention to detail and precision.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md border-t-4 border-primary">
              <h3 className="text-xl font-bold mb-3">Quality Materials</h3>
              <p className="text-gray-700">
                We use only high-quality materials and trusted brands to ensure lasting results. We never cut corners on materials because we want your project to stand the test of time.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md border-t-4 border-primary">
              <h3 className="text-xl font-bold mb-3">Local Expertise</h3>
              <p className="text-gray-700">
                As a family-owned business serving White Rock, Surrey, Langley, and surrounding areas, we understand local building requirements and neighborhood aesthetics.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Ready to start your project?</h2>
            <p className="text-xl text-white mb-8">
              Contact us today for a free, no-obligation estimate on your home improvement project.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/estimate" className="bg-white hover:bg-gray-100 text-primary font-bold py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Get a Free Estimate
              </Link>
              <a href="tel:+16043175711" className="bg-transparent border-2 border-white text-white hover:bg-white/10 font-bold py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                <Phone size={18} className="mr-2" /> Call 604-317-5711
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Google Reviews Section */}
      <GoogleReviews />

      {/* Service Areas */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Our Service Areas</h2>
            <p className="text-lg text-gray-700 mb-10">
              We proudly serve homeowners throughout the Greater Vancouver area, including:
            </p>
            
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="bg-white border border-gray-200 p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                White Rock
              </div>
              <div className="bg-white border border-gray-200 p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                Surrey
              </div>
              <div className="bg-white border border-gray-200 p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                South Surrey
              </div>
              <div className="bg-white border border-gray-200 p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                Langley
              </div>
              <div className="bg-white border border-gray-200 p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                Cloverdale
              </div>
            </div>
            
            <p className="mt-8 text-gray-700">
              Not sure if we service your area? <Link to="/contact" className="text-primary hover:underline">Contact us</Link> today to find out!
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;