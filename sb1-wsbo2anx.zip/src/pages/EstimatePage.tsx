import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Paperclip, CheckCircle, X, Phone, Mail } from 'lucide-react';

const EstimatePage = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    message: ''
  });

  const [files, setFiles] = useState<File[]>([]);
  const [submitted, setSubmitted] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setFiles(prevFiles => [...prevFiles, ...newFiles]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prevFiles => prevFiles.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real implementation, you would handle form submission to your backend here
    // For demonstration purposes, we'll just set submitted to true
    console.log('Form submitted:', formData);
    console.log('Files:', files);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-light py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-6">
                <CheckCircle size={32} className="text-green-600" />
              </div>
              <h1 className="text-3xl font-bold mb-4">Thank You!</h1>
              <p className="text-xl text-gray-700 mb-6">
                Your estimate request has been successfully submitted. We'll get back to you within 24-48 hours to discuss your project.
              </p>
              <p className="text-gray-700 mb-8">
                A confirmation email has been sent to {formData.email} with a summary of your request.
              </p>
              <button
                onClick={() => window.location.href = '/'}
                className="bg-primary hover:bg-red-700 text-white font-medium py-3 px-8 rounded-md transition-colors"
              >
                Return to Home
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Hero Section */}
      <section 
        className="bg-cover bg-center py-20 relative" 
        style={{ 
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url(https://images.unsplash.com/photo-1589939705384-5185137a7f0f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80)'
        }}
      >
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Free Project Estimate
            </h1>
            <p className="text-xl text-white mb-8">
              Fill out the form below to get a free, no-obligation estimate for your project.
            </p>
          </div>
        </div>
      </section>

      {/* Estimate Form */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/3 bg-primary p-8 text-white">
                <h2 className="text-2xl font-bold mb-6">How It Works</h2>
                
                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="bg-white text-primary w-8 h-8 rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                      1
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">Submit Your Request</h3>
                      <p className="text-sm text-white/80">
                        Fill out the form with details about your project and any photos.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-white text-primary w-8 h-8 rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                      2
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">We'll Contact You</h3>
                      <p className="text-sm text-white/80">
                        A member of our team will reach out within 24-48 hours to discuss your project.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-white text-primary w-8 h-8 rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                      3
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">Get Your Estimate</h3>
                      <p className="text-sm text-white/80">
                        We'll provide a detailed, no-obligation estimate for your project.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-12 pt-8 border-t border-white/30">
                  <h3 className="font-bold mb-4">Why Choose Us</h3>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <CheckCircle size={16} className="mr-2 mt-1 flex-shrink-0" />
                      <span>38+ years of experience</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle size={16} className="mr-2 mt-1 flex-shrink-0" />
                      <span>Licensed & insured professionals</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle size={16} className="mr-2 mt-1 flex-shrink-0" />
                      <span>No call-out fees for estimates</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle size={16} className="mr-2 mt-1 flex-shrink-0" />
                      <span>Transparent, detailed quotes</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle size={16} className="mr-2 mt-1 flex-shrink-0" />
                      <span>Satisfaction guaranteed</span>
                    </li>
                  </ul>
                </div>
              </div>
              
              <div className="md:w-2/3 p-8">
                <div className="mb-8">
                  <div className="flex flex-col md:flex-row gap-4 mb-6">
                    <div className="flex items-center text-gray-700">
                      <Phone size={20} className="text-primary mr-2" />
                      <a href="tel:+16043175711" className="hover:text-primary transition-colors">604-317-5711</a>
                    </div>
                    <div className="flex items-center text-gray-700">
                      <Mail size={20} className="text-primary mr-2" />
                      <a href="mailto:info@whiterockhandyman.ca" className="hover:text-primary transition-colors">info@whiterockhandyman.ca</a>
                    </div>
                  </div>
                  <h2 className="text-2xl font-bold">Request an Estimate</h2>
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="firstName" className="block mb-2 font-medium">
                        First Name *
                      </label>
                      <input
                        type="text"
                        id="firstName"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="lastName" className="block mb-2 font-medium">
                        Last Name *
                      </label>
                      <input
                        type="text"
                        id="lastName"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="email" className="block mb-2 font-medium">
                        Email *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="phone" className="block mb-2 font-medium">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="address" className="block mb-2 font-medium">
                      Address *
                    </label>
                    <input
                      type="text"
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="message" className="block mb-2 font-medium">
                      Message *
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={5}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="Please describe your project in detail..."
                    ></textarea>
                  </div>
                  
                  <div>
                    <label className="block mb-2 font-medium">
                      Project Photos (Optional)
                    </label>
                    <div className="border-2 border-dashed border-gray-300 rounded-md p-4 mb-4">
                      <div className="flex items-center justify-center">
                        <label className="w-full flex flex-col items-center px-4 py-6 bg-white text-primary rounded-md tracking-wide cursor-pointer hover:bg-primary hover:text-white transition-colors">
                          <Paperclip size={28} />
                          <span className="mt-2 text-base">Upload photos of your project area</span>
                          <input 
                            type="file" 
                            className="hidden" 
                            multiple 
                            accept="image/*"
                            onChange={handleFileChange}
                          />
                        </label>
                      </div>
                    </div>
                    {files.length > 0 && (
                      <div className="mt-2">
                        <p className="font-medium mb-2">Uploaded Files:</p>
                        <ul className="space-y-2">
                          {files.map((file, index) => (
                            <li key={index} className="flex items-center justify-between bg-gray-100 p-2 rounded">
                              <span className="truncate">{file.name}</span>
                              <button 
                                type="button" 
                                onClick={() => removeFile(index)}
                                className="text-red-600 hover:text-red-800 transition-colors"
                              >
                                <X size={18} />
                              </button>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    <p className="text-sm text-gray-500 mt-2">
                      Max file size: 10MB each. Supported formats: JPG, PNG, HEIC
                    </p>
                  </div>
                  
                  <div className="border-t pt-6">
                    <div className="mb-6">
                      <label className="flex items-start">
                        <input
                          type="checkbox"
                          required
                          className="mr-2 mt-1"
                        />
                        <span className="text-sm text-gray-700">
                          I agree to receive communications from White Rock Handyman & Renovations regarding my estimate request. I understand my information will be used in accordance with the privacy policy.
                        </span>
                      </label>
                    </div>
                    
                    <button
                      type="submit"
                      className="w-full bg-primary hover:bg-red-700 text-white font-medium py-3 px-8 rounded-md transition-colors"
                    >
                      Submit Estimate Request
                    </button>
                    
                    <p className="text-sm text-gray-500 mt-4 text-center">
                      We'll get back to you within 24-48 hours with a response to your request.
                    </p>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Frequently Asked Questions</h2>
            
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">How accurate will my estimate be?</h3>
                <p className="text-gray-700">
                  Our estimates are detailed and comprehensive. While the final cost may vary depending on the specific requirements and any unforeseen issues, our estimates typically provide an accurate representation of project costs.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">Is there a charge for the estimate?</h3>
                <p className="text-gray-700">
                  No, we provide free estimates for all projects within our service area. We believe in transparent pricing with no hidden fees or obligations.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">How soon can you start my project?</h3>
                <p className="text-gray-700">
                  Our project start date depends on our current schedule and the scope of your project. After reviewing your estimate request, we'll provide an estimated timeline for when we can begin your project.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">Do I need to be present for the estimate?</h3>
                <p className="text-gray-700">
                  For most projects, it's beneficial for you to be present during the initial consultation so we can discuss your needs and preferences in person. However, we can make arrangements if you're unable to be there.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default EstimatePage;