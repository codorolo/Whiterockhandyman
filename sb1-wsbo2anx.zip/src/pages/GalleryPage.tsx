import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { InstagramEmbed } from 'react-social-media-embed';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

// Instagram posts
const instagramPosts = [
  { id: 1, url: 'https://www.instagram.com/p/DIIKLyLvS4E/' },
  { id: 2, url: 'https://www.instagram.com/p/DGuVZMYxfov/' },
  { id: 3, url: 'https://www.instagram.com/p/DGbQY74S_Fs/' },
  { id: 4, url: 'https://www.instagram.com/p/DGCfo6LRcxT/' },
  { id: 5, url: 'https://www.instagram.com/p/DFTPtMhyziC/' },
  { id: 6, url: 'https://www.instagram.com/p/C9bHXvESCwe/' },
  { id: 7, url: 'https://www.instagram.com/p/C8Sh06gyOxI/' },
  { id: 8, url: 'https://www.instagram.com/p/C4W8P9NLgS_/' },
  { id: 9, url: 'https://www.instagram.com/p/C3yieKFvkud/' },
  { id: 10, url: 'https://www.instagram.com/p/C3Orq33RYXV/' },
  { id: 11, url: 'https://www.instagram.com/p/C28TG0ovBt9/' },
  { id: 12, url: 'https://www.instagram.com/p/C0A9VLoL_Mm/' },
  { id: 13, url: 'https://www.instagram.com/p/CtFm26GPrvB/' },
  { id: 14, url: 'https://www.instagram.com/p/CszwunNJvYp/' },
  { id: 15, url: 'https://www.instagram.com/p/CpjgkFhO0BQ/' },
  { id: 16, url: 'https://www.instagram.com/p/CoBbHArL-Uw/' },
  { id: 17, url: 'https://www.instagram.com/p/CmKPZS4vODK/' },
  { id: 18, url: 'https://www.instagram.com/p/CkUtlI_Lur9/' },
  { id: 19, url: 'https://www.instagram.com/p/CjwvA5wulTb/' },
  { id: 20, url: 'https://www.instagram.com/p/CjHXgVmrghG/' },
  { id: 21, url: 'https://www.instagram.com/p/Ci5m_LvPwaK/' },
  { id: 22, url: 'https://www.instagram.com/p/CiMCmFwrnnt/' },
  { id: 23, url: 'https://www.instagram.com/p/Ch3LVkevo-5/' },
  { id: 24, url: 'https://www.instagram.com/p/ChGVIxLpNwr/' },
  { id: 25, url: 'https://www.instagram.com/p/CfuxGebJbku/' },
  { id: 26, url: 'https://www.instagram.com/p/Ce6voYUPF91/' },
  { id: 27, url: 'https://www.instagram.com/p/CepdT6ErDPM/' },
  { id: 28, url: 'https://www.instagram.com/p/CeZjUi3v1Cp/' },
  { id: 29, url: 'https://www.instagram.com/p/CeZgu4TvHA4/' },
  { id: 30, url: 'https://www.instagram.com/p/CeP8Cj2LTgX/' },
  { id: 31, url: 'https://www.instagram.com/p/Cd9OWcovfRo/' },
  { id: 32, url: 'https://www.instagram.com/p/CdzcqnvrJ2_/' },
  { id: 33, url: 'https://www.instagram.com/p/Cdzb7hurVeZ/' },
  { id: 34, url: 'https://www.instagram.com/p/CdzbYpILnPF/' },
  { id: 35, url: 'https://www.instagram.com/p/CdzaYjDroOn/' }
];

const GalleryPage = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const postsPerPage = 9;
  
  // Calculate total pages
  const totalPages = Math.ceil(instagramPosts.length / postsPerPage);
  
  // Get current posts
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = instagramPosts.slice(indexOfFirstPost, indexOfLastPost);
  
  // Change page
  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };
  
  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };
  
  return (
    <div>
      {/* Hero Section */}
      <section 
        className="bg-cover bg-center py-20 relative" 
        style={{ 
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url(https://images.unsplash.com/photo-1599619351208-3e6c839d6828?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80)'
        }}
      >
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Our Project Gallery
            </h1>
            <p className="text-xl text-white mb-8">
              View examples of our quality craftsmanship and attention to detail
            </p>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          {/* Instagram Posts */}
          <div className="max-w-6xl mx-auto">
            <h2 className="text-2xl font-bold mb-8 text-center">Our Recent Projects</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {currentPosts.map((post) => (
                <div key={post.id} className="h-[650px] flex justify-center">
                  <div className="bg-white rounded-lg shadow-md overflow-hidden">
                    <InstagramEmbed url={post.url} width={328} />
                  </div>
                </div>
              ))}
            </div>
            
            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center mt-12 gap-4">
                <button 
                  onClick={prevPage} 
                  disabled={currentPage === 1}
                  className={`flex items-center px-4 py-2 rounded-md ${
                    currentPage === 1 
                      ? "bg-gray-200 text-gray-500 cursor-not-allowed" 
                      : "bg-primary text-white hover:bg-red-700"
                  }`}
                >
                  <ChevronLeft size={20} className="mr-1" /> Previous
                </button>
                
                <div className="flex items-center px-4 py-2 bg-gray-100 rounded-md">
                  Page {currentPage} of {totalPages}
                </div>
                
                <button 
                  onClick={nextPage} 
                  disabled={currentPage === totalPages}
                  className={`flex items-center px-4 py-2 rounded-md ${
                    currentPage === totalPages 
                      ? "bg-gray-200 text-gray-500 cursor-not-allowed" 
                      : "bg-primary text-white hover:bg-red-700"
                  }`}
                >
                  Next <ChevronRight size={20} className="ml-1" />
                </button>
              </div>
            )}
          </div>
          
          <div className="max-w-4xl mx-auto mt-16 text-center">
            <p className="text-lg mb-4">
              Follow us on Instagram for more project photos:
            </p>
            <a 
              href="https://www.instagram.com/whiterockrenovations/" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="inline-block bg-primary hover:bg-red-700 text-white font-medium py-3 px-8 rounded-md transition-colors"
            >
              Follow @whiterockrenovations
            </a>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Ready to start your project?</h2>
            <p className="text-xl text-white mb-8">
              Contact us today for a free consultation and quote on your home improvement needs.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/estimate" className="bg-white hover:bg-gray-100 text-primary font-bold py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Get a Free Estimate
              </Link>
              <a href="tel:+16043175711" className="bg-transparent border-2 border-white text-white hover:bg-white/10 font-bold py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Call Us: 604-317-5711
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default GalleryPage;