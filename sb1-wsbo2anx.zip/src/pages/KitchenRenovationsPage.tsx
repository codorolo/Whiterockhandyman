import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, ArrowRight } from 'lucide-react';

const KitchenRenovationsPage = () => {
  return (
    <div>
      {/* Hero Section */}
      <section 
        className="bg-cover bg-center py-20 relative" 
        style={{ 
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url(https://images.unsplash.com/photo-1556912172-45b7abe8b7e1?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80)'
        }}
      >
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Kitchen Renovations
            </h1>
            <p className="text-xl text-white mb-8">
              Create the heart of your home with our expert kitchen renovation services.
            </p>
            <Link to="/estimate" className="bg-primary hover:bg-red-700 text-white font-medium py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
              Get a Free Estimate
            </Link>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-center">
              <div className="md:col-span-5">
                <img 
                  src="https://images.unsplash.com/photo-1556911220-bda9da8a1f2c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Modern Kitchen Renovation" 
                  className="rounded-lg shadow-md w-full h-auto"
                />
              </div>
              <div className="md:col-span-7">
                <h2 className="text-3xl font-bold mb-6">Expert Kitchen Renovations</h2>
                <p className="text-gray-700 mb-4">
                  The kitchen is the heart of your home—a place where family and friends gather, meals are prepared, and memories are made. Our professional kitchen renovation services can transform your existing space into the kitchen of your dreams.
                </p>
                <p className="text-gray-700 mb-4">
                  With over 38 years of experience, our team specializes in creating beautiful, functional kitchens that reflect your personal style while maximizing space and efficiency.
                </p>
                <p className="text-gray-700">
                  From complete kitchen remodels to cabinet updates and countertop replacements, we handle every aspect of your renovation with meticulous attention to detail and quality craftsmanship.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Kitchen Renovation Services */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Kitchen Renovation Services</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4 text-primary">Complete Kitchen Remodels</h3>
                <p className="text-gray-700 mb-4">
                  Transform your outdated kitchen with a comprehensive renovation. We handle everything from design to installation.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Custom layout design</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Demolition and removal</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Plumbing and electrical work</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Appliance installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Flooring installation</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4 text-primary">Cabinet Installation & Refacing</h3>
                <p className="text-gray-700 mb-4">
                  Update the look of your kitchen with new cabinets or refresh existing ones with our expert cabinet services.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Custom cabinet installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Cabinet refacing</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Cabinet hardware updates</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Cabinet painting and refinishing</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Storage solutions and organization</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4 text-primary">Countertops & Backsplashes</h3>
                <p className="text-gray-700 mb-4">
                  Upgrade your kitchen surfaces with beautiful, durable materials that complement your style.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Granite, quartz, and marble countertops</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Laminate and solid surface options</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Custom backsplash design and installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Sink and faucet installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Countertop lighting</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4 text-primary">Flooring & Lighting</h3>
                <p className="text-gray-700 mb-4">
                  Complete your kitchen renovation with durable flooring and effective lighting solutions.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Tile, hardwood, and vinyl flooring</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Recessed lighting installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Under-cabinet lighting</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Pendant and island lighting</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Energy-efficient lighting options</span>
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md mt-8">
              <h3 className="text-xl font-bold mb-4 text-primary">Additional Services</h3>
              <p className="text-gray-700 mb-6">
                We also offer these specialized kitchen renovation services:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Kitchen islands and peninsulas</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Pantry design and organization</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Smart kitchen technology integration</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Ventilation and range hood installation</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Custom storage solutions</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Energy-efficient upgrades</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Process */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Kitchen Renovation Process</h2>
            
            <div className="space-y-12">
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 flex justify-center md:justify-start mb-4 md:mb-0">
                  <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold flex-shrink-0">
                    1
                  </div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-xl font-bold mb-3">Initial Consultation</h3>
                  <p className="text-gray-700">
                    We start by understanding your vision, needs, and budget for your kitchen renovation. Our team will discuss your goals, measure your space, and assess the current layout to identify opportunities for improvement.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 flex justify-center md:justify-start mb-4 md:mb-0">
                  <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold flex-shrink-0">
                    2
                  </div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-xl font-bold mb-3">Design & Planning</h3>
                  <p className="text-gray-700">
                    Based on our consultation, we create a detailed design plan for your kitchen, including layout, materials, fixtures, and finishes. We'll work with you to refine the design until it perfectly meets your expectations.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 flex justify-center md:justify-start mb-4 md:mb-0">
                  <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold flex-shrink-0">
                    3
                  </div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-xl font-bold mb-3">Detailed Quote</h3>
                  <p className="text-gray-700">
                    We provide a comprehensive quote outlining all costs, materials, and timeframes for your kitchen renovation. Our transparent pricing ensures you know exactly what to expect with no hidden fees.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 flex justify-center md:justify-start mb-4 md:mb-0">
                  <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold flex-shrink-0">
                    4
                  </div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-xl font-bold mb-3">Demolition & Preparation</h3>
                  <p className="text-gray-700">
                    Once the project begins, we carefully remove existing cabinets, countertops, and fixtures. We protect adjoining areas of your home and ensure all demolition waste is properly disposed of.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 flex justify-center md:justify-start mb-4 md:mb-0">
                  <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold flex-shrink-0">
                    5
                  </div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-xl font-bold mb-3">Installation & Construction</h3>
                  <p className="text-gray-700">
                    Our skilled team handles all aspects of installation, including plumbing, electrical work, cabinetry, countertops, backsplashes, flooring, and lighting. Each step is completed with meticulous attention to detail.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 flex justify-center md:justify-start mb-4 md:mb-0">
                  <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold flex-shrink-0">
                    6
                  </div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-xl font-bold mb-3">Final Inspection & Walkthrough</h3>
                  <p className="text-gray-700">
                    Upon completion, we conduct a thorough inspection to ensure every detail meets our high standards. We'll walk you through your new kitchen, explain how everything works, and address any questions or concerns.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio/Gallery */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Our Kitchen Renovation Portfolio</h2>
            <p className="text-lg text-gray-700 mb-12">
              Browse examples of our recent kitchen renovation projects.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="overflow-hidden rounded-lg shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1556911220-bda9da8a1f2c?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                  alt="Modern Kitchen Design" 
                  className="w-full h-64 object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
              
              <div className="overflow-hidden rounded-lg shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1556909190-eccf4a8bf97a?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                  alt="Contemporary Kitchen Renovation" 
                  className="w-full h-64 object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
              
              <div className="overflow-hidden rounded-lg shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1591247378419-2c3579312788?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                  alt="Kitchen Island Design" 
                  className="w-full h-64 object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
            </div>
            
            <div className="mt-8">
              <Link to="/gallery" className="text-primary font-medium flex items-center justify-center hover:underline">
                View our full kitchen renovation gallery <ArrowRight size={18} className="ml-1" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">What Our Clients Say</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-primary">
                <p className="text-gray-700 mb-4 italic">
                  "The kitchen renovation by White Rock Handyman exceeded all our expectations. The design team listened to our needs and created a space that's both beautiful and functional. The craftsmanship is outstanding!"
                </p>
                <p className="font-bold">- Jennifer L., South Surrey</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-primary">
                <p className="text-gray-700 mb-4 italic">
                  "We couldn't be happier with our new kitchen. The team was professional, the work was completed on schedule, and the attention to detail was impressive. The custom cabinets and island are exactly what we wanted."
                </p>
                <p className="font-bold">- David M., Langley</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Frequently Asked Questions</h2>
            
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">How long does a kitchen renovation typically take?</h3>
                <p className="text-gray-700">
                  Kitchen renovations usually take between 4-8 weeks, depending on the scope of work. Simple updates may be quicker, while complete remodels with custom cabinetry might take longer. We'll provide a detailed timeline during our consultation.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">Can I use my kitchen during the renovation?</h3>
                <p className="text-gray-700">
                  For most of the renovation period, your kitchen will be partially or completely unusable. We recommend setting up a temporary kitchen elsewhere in your home. We'll work efficiently to minimize disruption and keep you informed about when utilities will be unavailable.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">What's the typical cost of a kitchen renovation?</h3>
                <p className="text-gray-700">
                  Kitchen renovation costs vary widely based on size, materials, and scope. Basic renovations might start around $20,000, while high-end custom kitchens can exceed $50,000. We provide detailed, transparent quotes after assessing your specific needs.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">Do you help with design and material selection?</h3>
                <p className="text-gray-700">
                  Yes, our design team will work closely with you to create a kitchen that matches your style and functional needs. We'll help you select cabinets, countertops, backsplashes, fixtures, and finishes that complement your taste and budget.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Ready to transform your kitchen?</h2>
            <p className="text-xl text-white mb-8">
              Contact us today to schedule a consultation and get a free estimate for your kitchen renovation project.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/estimate" className="bg-white hover:bg-gray-100 text-primary font-bold py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Get a Free Estimate
              </Link>
              <Link to="/contact" className="bg-transparent border-2 border-white text-white hover:bg-white/10 font-bold py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default KitchenRenovationsPage;