import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, Users, Calendar, Award, Shield, Star, PenTool as Tool } from 'lucide-react';
import GoogleReviews from '../components/GoogleReviews';

const AboutPage = () => {
  return (
    <div>
      {/* Hero Section */}
      <section 
        className="bg-cover bg-center py-20 relative" 
        style={{ 
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url(https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80)'
        }}
      >
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              About Us
            </h1>
            <p className="text-xl text-white mb-8">
              Quality craftsmanship and reliable service for over 37 years.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-center">
              <div className="md:col-span-5">
                <img 
                  src="https://images.unsplash.com/photo-1541888946425-d81bb19240f5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="White Rock Handyman Team" 
                  className="rounded-lg shadow-md w-full h-auto"
                />
                <div className="mt-4 bg-primary/10 rounded-lg p-4">
                  <div className="flex items-center mb-2">
                    <Star size={18} className="text-yellow-500 mr-1" />
                    <Star size={18} className="text-yellow-500 mr-1" />
                    <Star size={18} className="text-yellow-500 mr-1" />
                    <Star size={18} className="text-yellow-500 mr-1" />
                    <Star size={18} className="text-yellow-500 mr-1" />
                    <span className="ml-2 font-medium">4.9 stars (85+ reviews)</span>
                  </div>
                  <p className="text-sm">
                    "The most reliable and professional handyman service in White Rock. Wouldn't trust anyone else with our home renovations!" - Customer Review
                  </p>
                </div>
              </div>
              <div className="md:col-span-7">
                <h2 className="text-3xl font-bold mb-6">About White Rock Handyman & Renovations</h2>
                <p className="text-gray-700 mb-4">
                  At White Rock Handyman & Renovations, we are committed to delivering a premier customer experience with quality craftsmanship and reliable handyman services. Our top priority is getting the job done right the first time, ensuring your home improvements are completed to the highest standard.
                </p>
                
                <h3 className="text-xl font-bold mb-3">Licensed, Insured & Experienced</h3>
                <p className="text-gray-700 mb-4">
                  With over 37 years of experience, we specialize in a wide range of home repairs, renovations, and maintenance services. Whether it's a small handyman repair, a kitchen or bathroom renovation, or a full home upgrade, we bring skill, precision, and professionalism to every project. As a licensed and insured handyman in Surrey, White Rock, South Surrey, Cloverdale, and Langley, you can trust us to handle your home with care.
                </p>
                
                <h3 className="text-xl font-bold mb-3">Customer-Focused Service</h3>
                <p className="text-gray-700 mb-4">
                  We believe in making home improvements easy and stress-free. From your first call to the final cleanup, you will deal directly with an expert who treats your home like their own. Our goal is to provide high-quality handyman services that enhance your space while ensuring a hassle-free experience.
                </p>
                
                <h3 className="text-xl font-bold mb-3">Your Satisfaction, Guaranteed</h3>
                <p className="text-gray-700 mb-4">
                  At White Rock Handyman & Renovations, we save you time and money by using the best materials, expert techniques, and a commitment to exceptional service. Whether you're looking for "handyman near me", home renovations, or professional handyman services, we are here to help. Contact us today to bring your vision to life!
                </p>
                
                <div className="mt-6 flex flex-wrap items-center">
                  <div className="flex items-center mr-6 mb-2">
                    <Award size={20} className="text-primary mr-2" />
                    <span className="font-medium">Licensed & Insured</span>
                  </div>
                  <div className="flex items-center mr-6 mb-2">
                    <Shield size={20} className="text-primary mr-2" />
                    <span className="font-medium">WorkSafeBC Certified</span>
                  </div>
                  <div className="flex items-center mb-2">
                    <Tool size={20} className="text-primary mr-2" />
                    <span className="font-medium">Home Depot Pro</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Why Choose Us</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                  <Users size={32} className="text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Experienced Team</h3>
                <p className="text-gray-700">
                  Our team of skilled craftsmen brings decades of combined experience to every project. We take pride in our workmanship and treat your home with the utmost respect.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                  <Award size={32} className="text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Quality Materials</h3>
                <p className="text-gray-700">
                  We use only high-quality materials and products for all our projects. From premium paints to durable flooring, we believe that quality materials lead to lasting results.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                  <Calendar size={32} className="text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Reliable Service</h3>
                <p className="text-gray-700">
                  We value your time and always strive to complete projects on schedule. Our team is punctual, professional, and committed to providing reliable service you can count on.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle size={32} className="text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Satisfaction Guaranteed</h3>
                <p className="text-gray-700">
                  Your satisfaction is our top priority. We stand behind our work and are committed to ensuring that every client is completely satisfied with the results of their project.
                </p>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md mt-8">
              <h3 className="text-xl font-bold mb-4 text-center">Our Certifications & Affiliations</h3>
              <div className="flex flex-wrap justify-center items-center gap-8">
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto mb-2 flex items-center justify-center">
                    <Shield size={48} className="text-primary" />
                  </div>
                  <p className="font-medium">Licensed & Bonded</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto mb-2 flex items-center justify-center">
                    <Shield size={48} className="text-primary" />
                  </div>
                  <p className="font-medium">WorkSafeBC</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto mb-2 flex items-center justify-center">
                    <Tool size={48} className="text-primary" />
                  </div>
                  <p className="font-medium">Home Depot Pro</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto mb-2 flex items-center justify-center">
                    <Award size={48} className="text-primary" />
                  </div>
                  <p className="font-medium">Fully Insured</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Google Reviews Section */}
      <GoogleReviews />

      {/* Our Process */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Process</h2>
            
            <div className="space-y-12">
              <div className="flex flex-col md:flex-row items-start md:items-center">
                <div className="bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold mb-4 md:mb-0 md:mr-6 flex-shrink-0">
                  1
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Initial Consultation</h3>
                  <p className="text-gray-700">
                    We begin with a thorough consultation to understand your needs, preferences, and project requirements. This helps us provide an accurate quote and project timeline.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row items-start md:items-center">
                <div className="bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold mb-4 md:mb-0 md:mr-6 flex-shrink-0">
                  2
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Detailed Proposal</h3>
                  <p className="text-gray-700">
                    Based on our consultation, we provide a detailed proposal outlining the scope of work, materials to be used, project timeline, and cost estimate. We believe in transparency and clear communication from the start.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row items-start md:items-center">
                <div className="bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold mb-4 md:mb-0 md:mr-6 flex-shrink-0">
                  3
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Project Execution</h3>
                  <p className="text-gray-700">
                    Our skilled team works efficiently and with attention to detail to complete your project according to the agreed specifications. We maintain a clean work environment and minimize disruption to your daily routine.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row items-start md:items-center">
                <div className="bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold mb-4 md:mb-0 md:mr-6 flex-shrink-0">
                  4
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Final Walkthrough</h3>
                  <p className="text-gray-700">
                    Upon completion, we conduct a final walkthrough to ensure that every aspect of the project meets our high standards and your expectations. We address any concerns and make necessary adjustments to ensure your complete satisfaction.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Service Area */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Our Service Area</h2>
            <p className="text-lg text-gray-700 mb-8">
              We proudly serve White Rock and the surrounding communities including:
            </p>
            
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-md">White Rock</div>
              <div className="bg-white p-4 rounded-lg shadow-md">Surrey</div>
              <div className="bg-white p-4 rounded-lg shadow-md">South Surrey</div>
              <div className="bg-white p-4 rounded-lg shadow-md">Langley</div>
              <div className="bg-white p-4 rounded-lg shadow-md">Cloverdale</div>
            </div>
            
            <p className="mt-8 text-gray-700">
              Not sure if we service your area? Contact us today to find out!
            </p>
          </div>
        </div>
      </section>

      {/* Team Section (Optional) */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Meet Our Team</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-40 h-40 rounded-full overflow-hidden mx-auto mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=320&q=80" 
                    alt="Team Member" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold mb-1">John Smith</h3>
                <p className="text-primary font-medium mb-3">Founder & Lead Contractor</p>
                <p className="text-gray-700">
                  With over 37 years of experience in construction and renovation, John leads our team with exceptional expertise and attention to detail.
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-40 h-40 rounded-full overflow-hidden mx-auto mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=320&q=80" 
                    alt="Team Member" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold mb-1">Michael Rogers</h3>
                <p className="text-primary font-medium mb-3">Master Carpenter</p>
                <p className="text-gray-700">
                  Michael specializes in custom carpentry and has been creating beautiful, functional pieces for our clients for over 15 years.
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-40 h-40 rounded-full overflow-hidden mx-auto mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=320&q=80" 
                    alt="Team Member" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold mb-1">Emily Johnson</h3>
                <p className="text-primary font-medium mb-3">Design Consultant</p>
                <p className="text-gray-700">
                  Emily helps our clients visualize their renovation projects and ensures that the final results align perfectly with their vision and needs.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Ready to start your project?</h2>
            <p className="text-xl text-white mb-8">
              Contact White Rock Handyman & Renovations today to schedule a consultation and get a free estimate.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/estimate" className="bg-white hover:bg-gray-100 text-primary font-bold py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Get a Free Estimate
              </Link>
              <Link to="/contact" className="bg-transparent border-2 border-white text-white hover:bg-white/10 font-bold py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;