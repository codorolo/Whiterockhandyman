import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, ArrowRight } from 'lucide-react';

const BathroomRenovationsPage = () => {
  return (
    <div>
      {/* Hero Section */}
      <section 
        className="bg-cover bg-center py-20 relative" 
        style={{ 
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url(https://images.unsplash.com/photo-1604014237800-1c9102c219da?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80)'
        }}
      >
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Bathroom Renovations
            </h1>
            <p className="text-xl text-white mb-8">
              Transform your bathroom into a beautiful, functional space with our professional renovation services.
            </p>
            <Link to="/estimate" className="bg-primary hover:bg-red-700 text-white font-medium py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
              Get a Free Estimate
            </Link>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-center">
              <div className="md:col-span-5">
                <img 
                  src="https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Modern Bathroom Renovation" 
                  className="rounded-lg shadow-md w-full h-auto"
                />
              </div>
              <div className="md:col-span-7">
                <h2 className="text-3xl font-bold mb-6">Expert Bathroom Renovations</h2>
                <p className="text-gray-700 mb-4">
                  Whether you're looking for a complete bathroom remodel or a simple update, our team of experienced professionals can turn your vision into reality.
                </p>
                <p className="text-gray-700 mb-4">
                  With over 38 years of experience in bathroom renovations, we understand that your bathroom should be both beautiful and functional, reflecting your personal style while meeting your practical needs.
                </p>
                <p className="text-gray-700">
                  From luxurious master bathrooms to practical family bathrooms and powder rooms, we handle every aspect of your renovation with meticulous attention to detail and quality craftsmanship.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Bathroom Renovation Services */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Bathroom Renovation Services</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4 text-primary">Complete Bathroom Remodels</h3>
                <p className="text-gray-700 mb-4">
                  Transform your outdated bathroom with a complete renovation. We handle everything from design to installation.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Custom layout design</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Demolition and removal</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Plumbing and electrical work</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Fixture installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Tile work and flooring</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4 text-primary">Shower & Bathtub Installation</h3>
                <p className="text-gray-700 mb-4">
                  Upgrade your bathing experience with a new shower or tub installation tailored to your preferences.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Custom shower enclosures</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Bathtub replacement</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Tub-to-shower conversions</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Shower door installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Waterproofing</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4 text-primary">Vanity & Cabinetry</h3>
                <p className="text-gray-700 mb-4">
                  Maximize your bathroom storage and style with custom vanities and cabinetry solutions.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Custom vanity installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Medicine cabinet installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Storage solutions</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Countertop installation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Sink installation</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4 text-primary">Tile & Flooring</h3>
                <p className="text-gray-700 mb-4">
                  Beautiful, durable tile and flooring options to enhance your bathroom's appearance.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Ceramic and porcelain tile</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Natural stone tile</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Luxury vinyl flooring</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Custom shower niches</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                    <span>Heated flooring systems</span>
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md mt-8">
              <h3 className="text-xl font-bold mb-4 text-primary">Additional Services</h3>
              <p className="text-gray-700 mb-6">
                We also offer these specialized bathroom renovation services:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Accessible bathroom modifications</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Luxury upgrades (heated floors, towel warmers)</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Lighting design and installation</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Ventilation system upgrades</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Plumbing repairs and upgrades</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={18} className="text-primary mr-2 mt-1 flex-shrink-0" />
                  <span>Green/eco-friendly bathroom solutions</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Process */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Bathroom Renovation Process</h2>
            
            <div className="space-y-12">
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 flex justify-center md:justify-start mb-4 md:mb-0">
                  <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold flex-shrink-0">
                    1
                  </div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-xl font-bold mb-3">Consultation & Design</h3>
                  <p className="text-gray-700">
                    We begin by understanding your needs, preferences, and budget. Our design team will work with you to create a bathroom plan that meets your functional requirements and aesthetic vision.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 flex justify-center md:justify-start mb-4 md:mb-0">
                  <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold flex-shrink-0">
                    2
                  </div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-xl font-bold mb-3">Detailed Quote</h3>
                  <p className="text-gray-700">
                    After finalizing the design, we provide a comprehensive quote that outlines all costs, materials, and timeline. We're committed to transparency, so there won't be any surprises.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 flex justify-center md:justify-start mb-4 md:mb-0">
                  <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold flex-shrink-0">
                    3
                  </div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-xl font-bold mb-3">Preparation & Demolition</h3>
                  <p className="text-gray-700">
                    Once the project begins, we'll protect surrounding areas and carefully remove existing fixtures, finishes, and materials. All debris is properly disposed of in accordance with local regulations.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 flex justify-center md:justify-start mb-4 md:mb-0">
                  <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold flex-shrink-0">
                    4
                  </div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-xl font-bold mb-3">Plumbing & Electrical</h3>
                  <p className="text-gray-700">
                    Our licensed professionals will update or install all necessary plumbing and electrical systems according to code requirements, ensuring everything functions properly.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 flex justify-center md:justify-start mb-4 md:mb-0">
                  <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold flex-shrink-0">
                    5
                  </div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-xl font-bold mb-3">Construction & Installation</h3>
                  <p className="text-gray-700">
                    We'll install new fixtures, tile, flooring, cabinetry, and other elements according to the design plan, with meticulous attention to detail at every step.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 flex justify-center md:justify-start mb-4 md:mb-0">
                  <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold flex-shrink-0">
                    6
                  </div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-xl font-bold mb-3">Final Inspection & Walkthrough</h3>
                  <p className="text-gray-700">
                    Once construction is complete, we conduct a thorough inspection to ensure everything meets our high standards. We'll walk you through your new bathroom and address any questions or concerns.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio/Gallery */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Our Bathroom Renovation Portfolio</h2>
            <p className="text-lg text-gray-700 mb-12">
              Browse examples of our recent bathroom renovation projects.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="overflow-hidden rounded-lg shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                  alt="Modern Master Bathroom" 
                  className="w-full h-64 object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
              
              <div className="overflow-hidden rounded-lg shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1600566752355-35792bedcfea?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                  alt="Contemporary Shower Design" 
                  className="w-full h-64 object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
              
              <div className="overflow-hidden rounded-lg shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1507652313519-d4e9174996dd?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                  alt="Luxury Bathroom Vanity" 
                  className="w-full h-64 object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
            </div>
            
            <div className="mt-8">
              <Link to="/gallery" className="text-primary font-medium flex items-center justify-center hover:underline">
                View our full bathroom renovation gallery <ArrowRight size={18} className="ml-1" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">What Our Clients Say</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-primary">
                <p className="text-gray-700 mb-4 italic">
                  "White Rock Handyman transformed our outdated bathroom into a modern oasis. The quality of work was exceptional, and the team was professional and respectful of our home. We couldn't be happier with the results!"
                </p>
                <p className="font-bold">- Rebecca J., Surrey</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-primary">
                <p className="text-gray-700 mb-4 italic">
                  "We hired White Rock Handyman for our master bathroom renovation, and they exceeded our expectations. The project was completed on time and within budget, and the attention to detail was impressive."
                </p>
                <p className="font-bold">- Michael T., White Rock</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Frequently Asked Questions</h2>
            
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">How long does a bathroom renovation typically take?</h3>
                <p className="text-gray-700">
                  The duration depends on the scope of work, but most bathroom renovations take between 2-4 weeks to complete. We'll provide you with a detailed timeline during the consultation phase.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">Do you provide design services?</h3>
                <p className="text-gray-700">
                  Yes, we offer comprehensive design services to help you create your ideal bathroom. Our designers will work with you to select materials, fixtures, colors, and layouts that match your vision and budget.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">Are you licensed and insured?</h3>
                <p className="text-gray-700">
                  Absolutely. We are fully licensed, insured, and bonded, providing you with peace of mind throughout the renovation process. All our work is performed to code and meets local building requirements.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-3">How much does a bathroom renovation cost?</h3>
                <p className="text-gray-700">
                  Costs vary depending on the size of your bathroom, the quality of materials, and the extent of the renovation. We provide detailed quotes after our initial consultation to ensure transparency.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Ready to transform your bathroom?</h2>
            <p className="text-xl text-white mb-8">
              Contact us today to schedule a consultation and get a free estimate for your bathroom renovation project.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/estimate" className="bg-white hover:bg-gray-100 text-primary font-bold py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Get a Free Estimate
              </Link>
              <Link to="/contact" className="bg-transparent border-2 border-white text-white hover:bg-white/10 font-bold py-3 px-8 rounded-md transition-colors inline-flex items-center justify-center">
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default BathroomRenovationsPage;