import React, { useEffect } from 'react';

const GoogleReviews: React.FC = () => {
  useEffect(() => {
    // Load Elfsight widget script
    const elfsightScript = document.createElement('script');
    elfsightScript.src = 'https://static.elfsight.com/platform/platform.js';
    elfsightScript.async = true;
    
    // Append script to document
    document.body.appendChild(elfsightScript);

    // Cleanup function to remove script when component unmounts
    return () => {
      if (document.body.contains(elfsightScript)) {
        document.body.removeChild(elfsightScript);
      }
    };
  }, []);

  return (
    <section id="reviews" className="py-16 bg-gray-light">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
          </div>
          
          {/* Elfsight Google Reviews Widget */}
          <div className="elfsight-app-0a7e0dbe-8523-4425-b4c4-b3918845c965" data-elfsight-app-lazy></div>
        </div>
      </div>
    </section>
  );
};

export default GoogleReviews;