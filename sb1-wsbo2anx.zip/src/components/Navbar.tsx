import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Phone, ChevronDown } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const servicesRef = useRef<HTMLDivElement>(null);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleServices = () => {
    setIsServicesOpen(!isServicesOpen);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (servicesRef.current && !servicesRef.current.contains(event.target as Node)) {
        setIsServicesOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center">
            <img src="https://imgur.com/ppkFArL.png" alt="White Rock Handyman Logo" className="h-12 w-12 mr-3" />
            <div>
              <h1 className="text-xl font-bold text-secondary">White Rock</h1>
              <p className="text-sm font-medium text-primary">Handyman & Renovations</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex">
            <ul className="flex space-x-6 items-center">
              <li>
                <Link to="/" className="text-secondary hover:text-primary font-medium transition-colors">
                  Home
                </Link>
              </li>
              <li className="relative" ref={servicesRef}>
                <button 
                  onClick={toggleServices}
                  className="flex items-center text-secondary hover:text-primary font-medium transition-colors"
                >
                  Services <ChevronDown size={16} className="ml-1" />
                </button>
                {isServicesOpen && (
                  <div className="absolute top-full left-0 mt-2 w-56 bg-white shadow-lg rounded-md z-50 py-2">
                    <Link 
                      to="/services/bathroom-renovations" 
                      className="block px-4 py-2 text-secondary hover:bg-gray-100 hover:text-primary"
                      onClick={() => setIsServicesOpen(false)}
                    >
                      Bathroom Renovations
                    </Link>
                    <Link 
                      to="/services/kitchen-renovations" 
                      className="block px-4 py-2 text-secondary hover:bg-gray-100 hover:text-primary"
                      onClick={() => setIsServicesOpen(false)}
                    >
                      Kitchen Renovations
                    </Link>
                    <Link 
                      to="/services/handyman" 
                      className="block px-4 py-2 text-secondary hover:bg-gray-100 hover:text-primary"
                      onClick={() => setIsServicesOpen(false)}
                    >
                      Handyman Services
                    </Link>
                    <Link 
                      to="/services/commercial" 
                      className="block px-4 py-2 text-secondary hover:bg-gray-100 hover:text-primary"
                      onClick={() => setIsServicesOpen(false)}
                    >
                      Commercial Services
                    </Link>
                    <Link 
                      to="/services" 
                      className="block px-4 py-2 text-secondary hover:bg-gray-100 hover:text-primary"
                      onClick={() => setIsServicesOpen(false)}
                    >
                      All Services
                    </Link>
                  </div>
                )}
              </li>
              <li>
                <Link to="/gallery" className="text-secondary hover:text-primary font-medium transition-colors">
                  Gallery
                </Link>
              </li>
              <li>
                <Link to="/rates" className="text-secondary hover:text-primary font-medium transition-colors">
                  Rates
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-secondary hover:text-primary font-medium transition-colors">
                  About
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-secondary hover:text-primary font-medium transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </nav>

          <div className="hidden md:flex space-x-4">
            <a href="tel:+16043175711" className="bg-secondary hover:bg-gray-800 text-white py-2 px-4 rounded-md font-medium transition-colors flex items-center">
              <Phone size={16} className="mr-2" /> Call Now
            </a>
            <Link to="/estimate" className="bg-primary hover:bg-red-700 text-white py-2 px-4 rounded-md font-medium transition-colors">
              Free Estimate
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden text-secondary"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4">
            <ul className="flex flex-col space-y-4">
              <li>
                <Link
                  to="/"
                  className="block text-secondary hover:text-primary font-medium transition-colors"
                  onClick={toggleMenu}
                >
                  Home
                </Link>
              </li>
              <li>
                <div className="mb-2">
                  <button
                    className="text-left w-full flex items-center justify-between text-secondary hover:text-primary font-medium transition-colors"
                    onClick={toggleServices}
                  >
                    Services <ChevronDown size={16} />
                  </button>
                </div>
                {isServicesOpen && (
                  <ul className="pl-4 space-y-2 mb-2">
                    <li>
                      <Link
                        to="/services/bathroom-renovations"
                        className="block text-secondary hover:text-primary transition-colors"
                        onClick={toggleMenu}
                      >
                        Bathroom Renovations
                      </Link>
                    </li>
                    <li>
                      <Link
                        to="/services/kitchen-renovations"
                        className="block text-secondary hover:text-primary transition-colors"
                        onClick={toggleMenu}
                      >
                        Kitchen Renovations
                      </Link>
                    </li>
                    <li>
                      <Link
                        to="/services/handyman"
                        className="block text-secondary hover:text-primary transition-colors"
                        onClick={toggleMenu}
                      >
                        Handyman Services
                      </Link>
                    </li>
                    <li>
                      <Link
                        to="/services/commercial"
                        className="block text-secondary hover:text-primary transition-colors"
                        onClick={toggleMenu}
                      >
                        Commercial Services
                      </Link>
                    </li>
                    <li>
                      <Link
                        to="/services"
                        className="block text-secondary hover:text-primary transition-colors"
                        onClick={toggleMenu}
                      >
                        All Services
                      </Link>
                    </li>
                  </ul>
                )}
              </li>
              <li>
                <Link
                  to="/gallery"
                  className="block text-secondary hover:text-primary font-medium transition-colors"
                  onClick={toggleMenu}
                >
                  Gallery
                </Link>
              </li>
              <li>
                <Link
                  to="/rates"
                  className="block text-secondary hover:text-primary font-medium transition-colors"
                  onClick={toggleMenu}
                >
                  Rates
                </Link>
              </li>
              <li>
                <Link
                  to="/about"
                  className="block text-secondary hover:text-primary font-medium transition-colors"
                  onClick={toggleMenu}
                >
                  About
                </Link>
              </li>
              <li>
                <Link
                  to="/contact"
                  className="block text-secondary hover:text-primary font-medium transition-colors"
                  onClick={toggleMenu}
                >
                  Contact
                </Link>
              </li>
              <li className="pt-2">
                <a href="tel:+16043175711" className="block w-full bg-secondary hover:bg-gray-800 text-white py-2 px-4 rounded-md font-medium transition-colors text-center mb-2">
                  <Phone size={16} className="inline-block mr-2" /> Call Now
                </a>
                <Link to="/estimate" className="block w-full bg-primary hover:bg-red-700 text-white py-2 px-4 rounded-md font-medium transition-colors text-center">
                  Free Estimate
                </Link>
              </li>
            </ul>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Navbar;