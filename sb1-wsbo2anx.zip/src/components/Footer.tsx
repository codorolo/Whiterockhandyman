import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Instagram, Clock, Award, Shield, Check } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-secondary text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Link to="/" className="flex items-center mb-4">
              <img src="https://imgur.com/ppkFArL.png" alt="White Rock Handyman Logo" className="h-12 w-12 mr-3" />
              <div>
                <h2 className="text-xl font-bold text-white">White Rock</h2>
                <p className="text-sm font-medium text-primary">Handyman & Renovations</p>
              </div>
            </Link>
            <p className="mb-4">
              Professional handyman and renovation services for all your home improvement needs with 37+ years of experience.
            </p>
            <div className="flex items-center mb-2">
              <Award size={16} className="text-primary mr-2" />
              <span className="text-sm">Licensed & Insured</span>
            </div>
            <div className="flex items-center mb-2">
              <Shield size={16} className="text-primary mr-2" />
              <span className="text-sm">WorkSafeBC Certified</span>
            </div>
            <div className="flex items-center">
              <Check size={16} className="text-primary mr-2" />
              <span className="text-sm">Home Depot Pro</span>
            </div>
          </div>

          <div className="md:col-span-1">
            <h3 className="text-lg font-bold mb-4">Services</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/services/bathroom-renovations" className="hover:text-primary transition-colors">
                  Bathroom Renovations
                </Link>
              </li>
              <li>
                <Link to="/services/kitchen-renovations" className="hover:text-primary transition-colors">
                  Kitchen Renovations
                </Link>
              </li>
              <li>
                <Link to="/services/handyman" className="hover:text-primary transition-colors">
                  Handyman Services
                </Link>
              </li>
              <li>
                <Link to="/services/commercial" className="hover:text-primary transition-colors">
                  Commercial Services
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-primary transition-colors">
                  Painting
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-primary transition-colors">
                  Flooring
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-primary transition-colors">
                  Carpentry
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-primary transition-colors">
                  Basement Finishing
                </Link>
              </li>
            </ul>
          </div>

          <div className="md:col-span-1">
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/gallery" className="hover:text-primary transition-colors">
                  Project Gallery
                </Link>
              </li>
              <li>
                <Link to="/rates" className="hover:text-primary transition-colors">
                  Rates & Pricing
                </Link>
              </li>
              <li>
                <Link to="/estimate" className="hover:text-primary transition-colors">
                  Free Estimate
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-primary transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-primary transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <a href="#reviews" className="hover:text-primary transition-colors">
                  Reviews
                </a>
              </li>
              <li>
                <Link to="/privacy" className="hover:text-primary transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="hover:text-primary transition-colors">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>

          <div className="md:col-span-1">
            <h3 className="text-lg font-bold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Phone size={18} className="mr-2 mt-1 text-primary" />
                <span>604-317-5711</span>
              </li>
              <li className="flex items-start">
                <Mail size={18} className="mr-2 mt-1 text-primary" />
                <span>info@whiterockhandyman.ca</span>
              </li>
              <li className="flex items-start">
                <MapPin size={18} className="mr-2 mt-1 text-primary" />
                <span>18232 21A Avenue<br />Surrey, BC V3Z 9W2</span>
              </li>
              <li className="flex items-start mt-4">
                <Clock size={18} className="mr-2 mt-1 text-primary" />
                <div>
                  <h4 className="font-medium mb-1">Hours:</h4>
                  <p>Monday to Friday: 8:00 AM - 4:00 PM</p>
                  <p>Saturday & Sunday: Closed</p>
                </div>
              </li>
            </ul>
            
            <div className="mt-4">
              <h4 className="font-medium mb-2">Service Areas:</h4>
              <p className="text-sm">White Rock, Surrey, South Surrey, Cloverdale, Langley</p>
            </div>
            
            <div className="flex space-x-4 mt-4">
              <a href="#" className="text-white hover:text-primary transition-colors" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-white hover:text-primary transition-colors" aria-label="Instagram">
                <Instagram size={20} />
              </a>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-black py-4">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm">&copy; 2025 White Rock Handyman & Renovations. All rights reserved.</p>
            <div className="flex items-center mt-2 md:mt-0">
              <div className="flex items-center text-yellow-400 mr-3">
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                </svg>
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                </svg>
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                </svg>
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                </svg>
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                </svg>
              </div>
              <a href="#reviews" className="text-sm text-gray-400 hover:text-white transition-colors">
                4.9 Stars (85+ Reviews)
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;